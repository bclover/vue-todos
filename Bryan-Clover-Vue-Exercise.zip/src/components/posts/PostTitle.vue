<template>
  <div>
    <!-- TODO: Break down Post component into multiple subcomponents -->
  </div>
</template>

<script>
export default {
  name: 'PostTitle',
  data() {
    return {
    };
  },
};
</script>

<style scoped>

</style>
