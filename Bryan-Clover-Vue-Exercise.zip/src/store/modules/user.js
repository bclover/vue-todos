export const state = {
  userId: 1,
};

export const getters = {
  currentUserId: state => state.userId,
};

